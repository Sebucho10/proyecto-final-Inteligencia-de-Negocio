
CREATE DATABASE OLTP_SportRiosSA;
GO

USE OLTP_SportRiosSA;
GO

---
-- 2. CREACI�N DE TABLAS DE DIMENSIONES (5 Dimensiones)
---

-- Dimensi�n: Sedes
CREATE TABLE Dim_Sedes (
    pk_sede INT IDENTITY(1,1) NOT NULL,
    id_sede INT NOT NULL,
    nombre_sede VARCHAR(50) NOT NULL,
    direccion_sede VARCHAR(50) NOT NULL,
    CONSTRAINT PK_Dim_Sedes PRIMARY KEY (pk_sede)
);

-- Dimensi�n: Canchas
CREATE TABLE Dim_Canchas (
    pk_cancha INT IDENTITY(1,1) NOT NULL,
    id_cancha INT NOT NULL,
    nombre_cancha VARCHAR(50) NOT NULL,
    tipo_disciplina VARCHAR(50) NOT NULL,
    tipo_superficie VARCHAR(50) NOT NULL,
    tarifa_hora_dia DECIMAL(10, 2) NOT NULL,
    tarifa_hora_noche DECIMAL(10, 2) NOT NULL,
    CONSTRAINT PK_Dim_Canchas PRIMARY KEY (pk_cancha)
);

-- Dimensi�n: Clientes
CREATE TABLE Dim_Clientes (
    pk_cliente INT IDENTITY(1,1) NOT NULL,
    id_cliente INT NOT NULL,
    cedula VARCHAR(50) NOT NULL,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    telefono VARCHAR(50) NOT NULL,
    email VARCHAR(50) NOT NULL,
    CONSTRAINT PK_Dim_Clientes PRIMARY KEY (pk_cliente)
);

-- Dimensi�n: Empleados
CREATE TABLE Dim_Empleados (
    pk_empleado INT IDENTITY(1,1) NOT NULL,
    id_empleado INT NOT NULL,
    cedula VARCHAR(50) NOT NULL,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    telefono VARCHAR(50) NOT NULL,
    email VARCHAR(50) NOT NULL,
    rol_sistema VARCHAR(50) NOT NULL,
    CONSTRAINT PK_Dim_Empleados PRIMARY KEY (pk_empleado)
);

-- Dimensi�n: Tiempo
CREATE TABLE Dim_Tiempo (
    pk_tiempo INT IDENTITY(1,1) NOT NULL,
    id_tiempo INT NOT NULL,
    fecha_base DATE NOT NULL,
    a�o INT NOT NULL,
    semestre VARCHAR(50) NOT NULL,
    trimestre VARCHAR(50) NOT NULL,
    mes VARCHAR(50) NOT NULL,
    dia_semana VARCHAR(50) NOT NULL,
    CONSTRAINT PK_Dim_Tiempo PRIMARY KEY (pk_tiempo)
);

---
-- 3. CREACI�N DE LA TABLA DE HECHOS CON LLAVES FOR�NEAS INLINE
---

CREATE TABLE F_Operaciones (
    -- Declaraci�n de campos con sus relaciones directas
    pk_sede INT NOT NULL CONSTRAINT FK_F_Operaciones_Dim_Sedes REFERENCES Dim_Sedes (pk_sede),
    pk_cancha INT NOT NULL CONSTRAINT FK_F_Operaciones_Dim_Canchas REFERENCES Dim_Canchas (pk_cancha),
    pk_cliente INT NOT NULL CONSTRAINT FK_F_Operaciones_Dim_Clientes REFERENCES Dim_Clientes (pk_cliente),
    pk_empleado INT NOT NULL CONSTRAINT FK_F_Operaciones_Dim_Empleados REFERENCES Dim_Empleados (pk_empleado),
    pk_tiempo INT NOT NULL CONSTRAINT FK_F_Operaciones_Dim_Tiempo REFERENCES Dim_Tiempo (pk_tiempo),
    
    -- Atributos y M�tricas de la transacci�n
    pk_transaccion_origen INT NOT NULL,
    tipo_transaccion VARCHAR(50) NOT NULL,
    tipo_detalle VARCHAR(50) NOT NULL,
    estado_pago VARCHAR(50) NOT NULL,
    monto_ingreso DECIMAL(10, 2) NOT NULL,
    monto_gasto DECIMAL(10, 2) NOT NULL,
    total_horas DECIMAL(10, 2) NOT NULL,
    cantidad INT NOT NULL,
    id_nueva INT NOT NULL
);
GO













USE OLTP_SportRiosSA;
GO

--- Carga Dimension Canchas ---
SELECT 
    id_cancha,
    nombre_cancha,
    tipo_disciplina,
    tipo_superficie,
    tarifa_hora_dia,
    tarifa_hora_noche
FROM Dim_Canchas;

--- Carga Dimension Clientes ---
SELECT 
    id_cliente,
    cedula,
    nombre,
    apellido,
    telefono,
    email
FROM Dim_Clientes;

--- Carga Dimension Empleados ---
SELECT 
    id_empleado,
    cedula,
    nombre,
    apellido,
    telefono,
    email,
    rol_sistema
FROM Dim_Empleados;

--- Carga Dimension Sedes ---
SELECT 
    id_sede,
    nombre_sede,
    direccion_sede
FROM Dim_Sedes;

--- Carga Dimension Tiempo ---
SELECT 
    id_tiempo,
    fecha_base,
    a�o,
    semestre,
    trimestre,
    mes,
    dia_semana
FROM Dim_Tiempo;


--- Tarea de ejecutar ---

DELETE FROM dbo.F_Operaciones;

DELETE FROM dbo.Dim_Canchas;
DBCC CHECKIDENT ('dbo.Dim_Canchas', RESEED, 0);
GO

DELETE FROM dbo.Dim_Clientes;
DBCC CHECKIDENT ('dbo.Dim_Clientes', RESEED, 0);
GO

DELETE FROM dbo.Dim_Sedes;
DBCC CHECKIDENT ('dbo.Dim_Sedes', RESEED, 0);
GO

DELETE FROM dbo.Dim_Empleados;
DBCC CHECKIDENT ('dbo.Dim_Empleados', RESEED, 0);
GO

DELETE FROM dbo.Dim_Tiempo;
DBCC CHECKIDENT ('dbo.Dim_Tiempo', RESEED, 0);
GO


--- Dar acceso a la base de datos por si no salen las tablas o diagrama---
ALTER AUTHORIZATION ON DATABASE:: OLTP_SportRiosSA TO sa;
GO



--- Ejecutar este comando en la base de datos DW que esta vacia para que ejecute la tabla de hechos de SSIS ---
--- 1. Eliminar la tabla vac�a que no tiene el autoincrementable ---
DROP TABLE DW_SportRiosSA.dbo.F_Operaciones;
GO

-- 2. Volver a crearla correctamente con el IDENTITY(1,1) activo --- 
CREATE TABLE DW_SportRiosSA.dbo.F_Operaciones (
    id_nueva INT IDENTITY(1,1) NOT NULL,
    pk_sede INT NOT NULL,
    pk_cancha INT NOT NULL,
    pk_cliente INT NOT NULL,
    pk_empleado INT NOT NULL,
    pk_tiempo INT NOT NULL,
    pk_transaccion_origen INT NOT NULL,
    tipo_transaccion VARCHAR(50) NOT NULL,
    tipo_detalle VARCHAR(50) NOT NULL,
    estado_pago VARCHAR(50) NOT NULL,
    monto_ingreso NUMERIC(10,2) NOT NULL,
    monto_gasto NUMERIC(10,2) NOT NULL,
    total_horas NUMERIC(10,2) NOT NULL,
    cantidad NUMERIC(10,2) NOT NULL,
    CONSTRAINT pk_f_operaciones PRIMARY KEY (id_nueva)
);
GO


--- Carga de la tabla de hechos ---

SELECT 
    id_sede pk_sede,
    ReservasAlquileres.id_cancha pk_cancha,
    id_cliente pk_cliente,
    id_empleado_receptor pk_empleado,
    1 pk_tiempo, 
    id_reserva pk_transaccion_origen,
    tipo_horario tipo_transaccion,
    tipo_disciplina tipo_detalle,
    estado_pago,
    SUM(monto_ingreso) monto_ingreso,
    0.00 monto_gasto,
    SUM(DATEDIFF(hour, hora_inicio, hora_fin)) total_horas,
    COUNT(id_reserva) cantidad
FROM sportrios_alquiler_db.dbo.ReservasAlquileres
JOIN sportrios_alquiler_db.dbo.Canchas 
  ON ReservasAlquileres.id_cancha = Canchas.id_cancha
GROUP BY 
    id_sede,
    ReservasAlquileres.id_cancha,
    id_cliente,
    id_empleado_receptor,
    id_reserva,
    tipo_horario,
    tipo_disciplina,
    estado_pago









---vaciar y insertar datos a todos los campos ---
USE OLTP_SportRiosSA;
GO

DELETE FROM dbo.F_Operaciones; 
GO

DELETE FROM dbo.Dim_Canchas;
DELETE FROM dbo.Dim_Clientes;
DELETE FROM dbo.Dim_Empleados;
DELETE FROM dbo.Dim_Sedes;
DELETE FROM dbo.Dim_Tiempo;
GO

DBCC CHECKIDENT ('dbo.Dim_Canchas', RESEED, 0);
DBCC CHECKIDENT ('dbo.Dim_Clientes', RESEED, 0);
DBCC CHECKIDENT ('dbo.Dim_Empleados', RESEED, 0);
DBCC CHECKIDENT ('dbo.Dim_Sedes', RESEED, 0);
DBCC CHECKIDENT ('dbo.Dim_Tiempo', RESEED, 0);
GO





-- 1. Asegurar que usamos la base de datos del Data Warehouse
USE DW_SportRiosSA;
GO

-- 2. Limpiar por completo la tabla de hechos antes de tocar las dimensiones
DELETE FROM DW_SportRiosSA.dbo.F_Operaciones;
GO

-- 3. Sincronizar Dim_Sedes
DELETE FROM DW_SportRiosSA.dbo.Dim_Sedes;
SET IDENTITY_INSERT DW_SportRiosSA.dbo.Dim_Sedes ON;
INSERT INTO DW_SportRiosSA.dbo.Dim_Sedes (pk_sede, id_sede, nombre_sede, direccion_sede)
SELECT pk_sede, id_sede, nombre_sede, direccion_sede FROM OLTP_SportRiosSA.dbo.Dim_Sedes;
SET IDENTITY_INSERT DW_SportRiosSA.dbo.Dim_Sedes OFF;
GO

-- 4. Sincronizar Dim_Canchas
DELETE FROM DW_SportRiosSA.dbo.Dim_Canchas;
SET IDENTITY_INSERT DW_SportRiosSA.dbo.Dim_Canchas ON;
INSERT INTO DW_SportRiosSA.dbo.Dim_Canchas (pk_cancha, id_cancha, nombre_cancha, tipo_disciplina, tipo_superficie, tarifa_hora_dia, tarifa_hora_noche)
SELECT pk_cancha, id_cancha, nombre_cancha, tipo_disciplina, tipo_superficie, tarifa_hora_dia, tarifa_hora_noche FROM OLTP_SportRiosSA.dbo.Dim_Canchas;
SET IDENTITY_INSERT DW_SportRiosSA.dbo.Dim_Canchas OFF;
GO

-- 5. Sincronizar Dim_Clientes
DELETE FROM DW_SportRiosSA.dbo.Dim_Clientes;
SET IDENTITY_INSERT DW_SportRiosSA.dbo.Dim_Clientes ON;
INSERT INTO DW_SportRiosSA.dbo.Dim_Clientes (pk_cliente, id_cliente, cedula, nombre, apellido, telefono, email)
SELECT pk_cliente, id_cliente, cedula, nombre, apellido, telefono, email FROM OLTP_SportRiosSA.dbo.Dim_Clientes;
SET IDENTITY_INSERT DW_SportRiosSA.dbo.Dim_Clientes OFF;
GO

-- 6. Sincronizar Dim_Empleados
DELETE FROM DW_SportRiosSA.dbo.Dim_Empleados;
SET IDENTITY_INSERT DW_SportRiosSA.dbo.Dim_Empleados ON;
INSERT INTO DW_SportRiosSA.dbo.Dim_Empleados (pk_empleado, id_empleado, cedula, nombre, apellido, telefono, email, rol_sistema)
SELECT pk_empleado, id_empleado, cedula, nombre, apellido, telefono, email, rol_sistema FROM OLTP_SportRiosSA.dbo.Dim_Empleados;
SET IDENTITY_INSERT DW_SportRiosSA.dbo.Dim_Empleados OFF;
GO

-- 7. Sincronizar Dim_Tiempo
DELETE FROM DW_SportRiosSA.dbo.Dim_Tiempo;
SET IDENTITY_INSERT DW_SportRiosSA.dbo.Dim_Tiempo ON;
INSERT INTO DW_SportRiosSA.dbo.Dim_Tiempo (pk_tiempo, id_tiempo, fecha_base, a�o, semestre, trimestre, mes, dia_semana)
SELECT pk_tiempo, id_tiempo, fecha_base, a�o, semestre, trimestre, mes, dia_semana FROM OLTP_SportRiosSA.dbo.Dim_Tiempo;
SET IDENTITY_INSERT DW_SportRiosSA.dbo.Dim_Tiempo OFF;
GO

-- 8. Copiar los datos perfectos a la tabla de hechos (id_nueva es IDENTITY, por eso no se incluye en el insert)
INSERT INTO DW_SportRiosSA.dbo.F_Operaciones (pk_sede, pk_cancha, pk_cliente, pk_empleado, pk_tiempo, pk_transaccion_origen, tipo_transaccion, tipo_detalle, estado_pago, monto_ingreso, monto_gasto, total_horas, cantidad)
SELECT pk_sede, pk_cancha, pk_cliente, pk_empleado, pk_tiempo, pk_transaccion_origen, tipo_transaccion, tipo_detalle, estado_pago, monto_ingreso, monto_gasto, total_horas, cantidad 
FROM OLTP_SportRiosSA.dbo.F_Operaciones;
GO















-------------------------------------------------------------------------------
-- 3. POBLADO DE LA TABLA DE HECHOS (Versi�n corregida con TOP 1)
-------------------------------------------------------------------------------
INSERT INTO F_Operaciones (pk_sede, pk_cancha, pk_cliente, pk_empleado, pk_tiempo, pk_transaccion_origen, tipo_transaccion, tipo_detalle, estado_pago, monto_ingreso, monto_gasto, total_horas, cantidad, id_nueva) VALUES

-- === HIST�RICO 2024 ===
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 10), 1, 1, 1, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20240115), 501, 'Reserva', 'Alquiler Cancha', 'Pagado', 50.00, 0.00, 2.00, 1, 1001),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 20), 2, 2, 2, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20240322), 502, 'Reserva', 'Alquiler Cancha', 'Cancelado', 0.00, 18.00, 1.50, 1, 1002),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 30), 3, 3, 3, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20240610), 503, 'Reserva', 'Alquiler Cancha', 'Pagado', 60.00, 0.00, 3.00, 1, 1003),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 40), 4, 4, 4, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20240805), 504, 'Mantenimiento', 'Compra Redes', 'Pagado', 0.00, 120.00, 0.00, 4, 1004),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 50), 5, 5, 5, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20241120), 505, 'Reserva', 'Alquiler Cancha', 'Cancelado', 0.00, 35.00, 1.00, 1, 1005),

-- === HIST�RICO 2025 ===
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 60), 6, 6, 6, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20250214), 506, 'Reserva', 'Alquiler Cancha', 'Pagado', 80.00, 0.00, 2.00, 1, 1006),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 70), 7, 7, 7, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20250418), 507, 'Reserva', 'Alquiler Cancha', 'Pendiente', 45.00, 0.00, 3.00, 1, 1007),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 10), 2, 8, 8, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20250525), 508, 'Mantenimiento', 'Pintura L�neas', 'Pagado', 0.00, 85.00, 0.00, 2, 1008),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 20), 3, 9, 9, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20250730), 509, 'Reserva', 'Alquiler Cancha', 'Cancelado', 0.00, 20.00, 1.00, 1, 1009),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 30), 4, 10, 10, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20250912), 510, 'Reserva', 'Alquiler Cancha', 'Pagado', 30.00, 0.00, 2.00, 1, 1010),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 40), 5, 11, 11, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20251031), 511, 'Reserva', 'Alquiler Cancha', 'Cancelado', 0.00, 70.00, 2.00, 1, 1011),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 50), 6, 12, 12, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20251224), 512, 'Reserva', 'Alquiler Cancha', 'Pagado', 120.00, 0.00, 4.00, 1, 1012),

-- === A�O ACTUAL 2026 ===
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 60), 7, 13, 13, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20260105), 513, 'Reserva', 'Alquiler Cancha', 'Pendiente', 15.00, 0.00, 1.00, 1, 1013),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 70), 1, 14, 14, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20260120), 514, 'Reserva', 'Alquiler Cancha', 'Cancelado', 0.00, 25.00, 1.00, 1, 1014),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 10), 3, 15, 15, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20260210), 515, 'Reserva', 'Alquiler Cancha', 'Cancelado', 0.00, 60.00, 2.00, 1, 1015),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 20), 5, 16, 16, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20260308), 516, 'Reserva', 'Alquiler Cancha', 'Cancelado', 0.00, 35.00, 1.00, 1, 1016),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 30), 7, 17, 17, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20260415), 517, 'Reserva', 'Alquiler Cancha', 'Pagado', 45.00, 0.00, 3.00, 1, 1017),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 40), 2, 18, 18, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20260501), 518, 'Reserva', 'Alquiler Cancha', 'Pendiente', 24.00, 0.00, 2.00, 1, 1018),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 50), 4, 19, 19, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20260515), 519, 'Reserva', 'Alquiler Cancha', 'Pendiente', 10.00, 0.00, 1.00, 1, 1019),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 60), 1, 20, 20, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20260601), 520, 'Reserva', 'Alquiler Cancha', 'Cancelado', 0.00, 50.00, 2.00, 1, 1020),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 70), 3, 21, 21, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20260605), 521, 'Reserva', 'Alquiler Cancha', 'Pendiente', 40.00, 0.00, 2.00, 1, 1021),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 10), 6, 22, 22, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20260610), 522, 'Reserva', 'Alquiler Cancha', 'Pagado', 90.00, 0.00, 3.00, 1, 1022),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 20), 4, 23, 23, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20260615), 523, 'Cafeter�a', 'Venta Snacks', 'Pagado', 45.00, 0.00, 0.00, 12, 1023),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 30), 1, 24, 24, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20260620), 524, 'Reserva', 'Alquiler Cancha', 'Pagado', 25.00, 0.00, 1.00, 1, 1024),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 40), 2, 25, 25, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20260625), 525, 'Reserva', 'Alquiler Cancha', 'Cancelado', 0.00, 24.00, 2.00, 1, 1025),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 50), 7, 26, 26, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20260105), 526, 'Mantenimiento', 'Reparaci�n Vidrio', 'Pagado', 0.00, 250.00, 0.00, 1, 1026),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 60), 3, 27, 27, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20260308), 527, 'Reserva', 'Alquiler Cancha', 'Cancelado', 0.00, 20.00, 1.00, 1, 1027),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 70), 5, 28, 28, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20260415), 528, 'Reserva', 'Alquiler Cancha', 'Pagado', 75.00, 0.00, 3.00, 1, 1028),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 10), 2, 29, 29, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20260501), 529, 'Reserva', 'Alquiler Cancha', 'Pendiente', 12.00, 0.00, 1.00, 1, 1029),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 20), 6, 30, 30, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20260601), 530, 'Reserva', 'Alquiler Cancha', 'Pagado', 60.00, 0.00, 2.00, 1, 1030),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 30), 1, 1, 1, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20241120), 531, 'Reserva', 'Alquiler Cancha', 'Cancelado', 0.00, 25.00, 1.00, 1, 1031),
((SELECT TOP 1 pk_sede FROM Dim_Sedes WHERE id_sede = 40), 4, 2, 2, (SELECT TOP 1 pk_tiempo FROM Dim_Tiempo WHERE id_tiempo = 20251224), 532, 'Reserva', 'Alquiler Cancha', 'Pagado', 20.00, 0.00, 2.00, 1, 1032);


